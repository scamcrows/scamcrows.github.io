<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>403 Forbidden</title>
</head><body>
<h1>Forbidden</h1>
<p>You don't have permission to access /news/header/header.js
on this server.<br />
Server unable to read htaccess file, denying access to be safe</p>
<p>Additionally, a 403 Forbidden
error was encountered while trying to use an ErrorDocument to handle the request.</p>
<hr>
<address>Apache/2.4.29 (Unix) mod_hive/6.6 OpenSSL/1.0.1e-fips mod_fastcgi/2.4.6 Server at snowcrows.com Port 443</address>
</body></html>
